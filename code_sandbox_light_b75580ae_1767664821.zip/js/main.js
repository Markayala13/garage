/* ===================================
   MAPLE MOTORSPORTS - JAVASCRIPT
   Elite Racing Team Interactivity
   =================================== */

// Initialize AOS (Animate On Scroll)
document.addEventListener('DOMContentLoaded', function() {
    AOS.init({
        duration: 1000,
        once: true,
        offset: 100,
        easing: 'ease-in-out'
    });
});

// ===== NAVIGATION =====
const navbar = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
const navLinkElements = document.querySelectorAll('.nav-link');

// Sticky Navbar on Scroll
window.addEventListener('scroll', function() {
    if (window.scrollY > 100) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Mobile Menu Toggle
hamburger.addEventListener('click', function() {
    hamburger.classList.toggle('active');
    navLinks.classList.toggle('active');
    document.body.style.overflow = navLinks.classList.contains('active') ? 'hidden' : '';
});

// Smooth Scroll & Active Link Update
navLinkElements.forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links
        navLinkElements.forEach(l => l.classList.remove('active'));
        
        // Add active class to clicked link
        this.classList.add('active');
        
        // Close mobile menu
        hamburger.classList.remove('active');
        navLinks.classList.remove('active');
        document.body.style.overflow = '';
        
        // Smooth scroll to section
        const targetId = this.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 80;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});

// Update active link on scroll
window.addEventListener('scroll', function() {
    let current = '';
    const sections = document.querySelectorAll('section');
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop && window.pageYOffset < sectionTop + sectionHeight) {
            current = section.getAttribute('id');
        }
    });
    
    navLinkElements.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ===== HERO STATS COUNTER ANIMATION =====
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Trigger counter animation when hero section is visible
const heroSection = document.querySelector('.hero');
const statsObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const statNumbers = document.querySelectorAll('.stat-number');
            
            // Animate first stat (5 drivers)
            if (statNumbers[0] && statNumbers[0].textContent !== '5') {
                animateCounter(statNumbers[0], 5, 1500);
            }
            
            // Animate second stat (2025)
            if (statNumbers[1] && statNumbers[1].textContent !== '2025') {
                animateCounter(statNumbers[1], 2025, 2000);
            }
            
            // Third stat shows 100% (no animation needed as it's text)
            
            statsObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.3 });

if (heroSection) {
    statsObserver.observe(heroSection);
}

// ===== DRIVER CARDS HOVER EFFECTS =====
const driverCards = document.querySelectorAll('.driver-card');

driverCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-10px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0) scale(1)';
    });
});

// ===== RACE CARDS INTERACTIVE =====
const raceCards = document.querySelectorAll('.race-card');

raceCards.forEach(card => {
    card.addEventListener('click', function() {
        const raceName = this.querySelector('.race-name').textContent;
        const raceDate = this.querySelector('.race-date').textContent;
        
        // Add subtle pulse effect on click
        this.style.animation = 'pulse 0.3s ease';
        setTimeout(() => {
            this.style.animation = '';
        }, 300);
    });
});

// ===== GALLERY LIGHTBOX EFFECT =====
const galleryItems = document.querySelectorAll('.gallery-item');

galleryItems.forEach(item => {
    item.addEventListener('click', function() {
        // Add click effect
        this.style.transform = 'scale(0.95)';
        setTimeout(() => {
            this.style.transform = 'scale(1)';
        }, 200);
        
        // In a full implementation, this would open a lightbox
        console.log('Gallery item clicked - lightbox would open here');
    });
});

// ===== PARTNER CARDS ANIMATION =====
const partnerCards = document.querySelectorAll('.partner-card');

partnerCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
        const icon = this.querySelector('i');
        if (icon) {
            icon.style.transform = 'scale(1.2) rotate(5deg)';
            icon.style.transition = 'transform 0.3s ease';
        }
    });
    
    card.addEventListener('mouseleave', function() {
        const icon = this.querySelector('i');
        if (icon) {
            icon.style.transform = 'scale(1) rotate(0deg)';
        }
    });
});

// ===== CONTACT FORM HANDLING =====

// Initialize EmailJS (IMPORTANT: Replace with actual public key)
// Get your key from: https://www.emailjs.com/
(function() {
    emailjs.init("YOUR_PUBLIC_KEY_HERE"); // Replace with actual EmailJS public key
})();

const contactForm = document.getElementById('contactForm');
const formMessage = document.getElementById('formMessage');

if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form data
        const formData = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            subject: document.getElementById('subject').value,
            message: document.getElementById('message').value
        };
        
        // Disable submit button
        const submitButton = contactForm.querySelector('.submit-button');
        const originalButtonText = submitButton.innerHTML;
        submitButton.innerHTML = '<span>SENDING...</span><i class="fas fa-spinner fa-spin"></i>';
        submitButton.disabled = true;
        
        // Send email using EmailJS
        // Note: Replace 'YOUR_SERVICE_ID' and 'YOUR_TEMPLATE_ID' with actual values
        emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', formData)
            .then(function(response) {
                console.log('SUCCESS!', response.status, response.text);
                
                // Show success message
                formMessage.textContent = 'Thank you! Your message has been sent successfully. We\'ll get back to you soon!';
                formMessage.className = 'form-message success';
                
                // Reset form
                contactForm.reset();
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
                
            }, function(error) {
                console.log('FAILED...', error);
                
                // Show error message
                formMessage.textContent = 'Oops! Something went wrong. Please try again or contact us directly at info@maplemotorsports.com';
                formMessage.className = 'form-message error';
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    formMessage.style.display = 'none';
                }, 5000);
            })
            .finally(function() {
                // Re-enable submit button
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
            });
    });
}

// ===== FORM INPUT ANIMATIONS =====
const formInputs = document.querySelectorAll('.form-group input, .form-group textarea');

formInputs.forEach(input => {
    input.addEventListener('focus', function() {
        this.parentElement.style.transform = 'scale(1.02)';
        this.parentElement.style.transition = 'transform 0.2s ease';
    });
    
    input.addEventListener('blur', function() {
        this.parentElement.style.transform = 'scale(1)';
    });
});

// ===== SCROLL TO TOP FUNCTIONALITY =====
// Add a "scroll to top" button (appears after scrolling down)
function createScrollToTopButton() {
    const scrollBtn = document.createElement('button');
    scrollBtn.innerHTML = '<i class="fas fa-chevron-up"></i>';
    scrollBtn.className = 'scroll-to-top';
    scrollBtn.style.cssText = `
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 50px;
        height: 50px;
        background: var(--primary-red);
        color: white;
        border: none;
        border-radius: 50%;
        font-size: 1.2rem;
        cursor: pointer;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s ease;
        z-index: 999;
        box-shadow: 0 4px 15px rgba(220, 20, 60, 0.4);
    `;
    
    scrollBtn.addEventListener('click', () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    scrollBtn.addEventListener('mouseenter', function() {
        this.style.transform = 'scale(1.1)';
        this.style.boxShadow = '0 6px 20px rgba(220, 20, 60, 0.6)';
    });
    
    scrollBtn.addEventListener('mouseleave', function() {
        this.style.transform = 'scale(1)';
        this.style.boxShadow = '0 4px 15px rgba(220, 20, 60, 0.4)';
    });
    
    document.body.appendChild(scrollBtn);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', () => {
        if (window.scrollY > 500) {
            scrollBtn.style.opacity = '1';
            scrollBtn.style.visibility = 'visible';
        } else {
            scrollBtn.style.opacity = '0';
            scrollBtn.style.visibility = 'hidden';
        }
    });
}

createScrollToTopButton();

// ===== PAGE LOAD ANIMATIONS =====
window.addEventListener('load', function() {
    // Add loaded class to body for any CSS transitions
    document.body.classList.add('loaded');
    
    // Refresh AOS
    AOS.refresh();
});

// ===== PERFORMANCE: Lazy Loading Images (if images are added) =====
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                if (img.dataset.src) {
                    img.src = img.dataset.src;
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// ===== PARALLAX EFFECT FOR HERO =====
window.addEventListener('scroll', function() {
    const scrolled = window.pageYOffset;
    const heroBackground = document.querySelector('.hero-background');
    
    if (heroBackground && scrolled <= window.innerHeight) {
        heroBackground.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// ===== RACING THEME: Dynamic Background Effects =====
function createRacingLines() {
    const hero = document.querySelector('.hero');
    if (!hero) return;
    
    // Create racing line elements
    for (let i = 0; i < 3; i++) {
        const line = document.createElement('div');
        line.className = 'racing-line';
        line.style.cssText = `
            position: absolute;
            width: 2px;
            height: 100px;
            background: linear-gradient(to bottom, transparent, var(--primary-red), transparent);
            top: -100px;
            left: ${20 + (i * 30)}%;
            animation: racingLine ${3 + i}s linear infinite;
            opacity: 0.3;
            z-index: 1;
        `;
        hero.appendChild(line);
    }
    
    // Add animation keyframes
    if (!document.getElementById('racing-animations')) {
        const style = document.createElement('style');
        style.id = 'racing-animations';
        style.textContent = `
            @keyframes racingLine {
                0% { top: -100px; opacity: 0; }
                50% { opacity: 0.3; }
                100% { top: 100%; opacity: 0; }
            }
        `;
        document.head.appendChild(style);
    }
}

createRacingLines();

// ===== CONSOLE MESSAGE (Easter Egg) =====
console.log('%c🏁 MAPLE MOTORSPORTS 🏁', 'color: #DC143C; font-size: 24px; font-weight: bold; text-shadow: 2px 2px 4px rgba(0,0,0,0.5);');
console.log('%cRacing Excellence. Championship Performance.', 'color: #fff; font-size: 14px; font-style: italic;');
console.log('%cWebsite crafted with passion for motorsports 🏎️', 'color: #b0b0b0; font-size: 12px;');
console.log('%cInterested in joining our team? Contact us at info@maplemotorsports.com', 'color: #DC143C; font-size: 12px;');

// ===== DEBUG MODE (for development) =====
const DEBUG = false;

if (DEBUG) {
    console.log('Navigation links:', navLinkElements);
    console.log('Driver cards:', driverCards);
    console.log('Race cards:', raceCards);
    console.log('Gallery items:', galleryItems);
}

// ===== ACCESSIBILITY: Focus visible for keyboard navigation =====
document.addEventListener('keydown', function(e) {
    if (e.key === 'Tab') {
        document.body.classList.add('keyboard-nav');
    }
});

document.addEventListener('mousedown', function() {
    document.body.classList.remove('keyboard-nav');
});

// Add focus styles
const focusStyle = document.createElement('style');
focusStyle.textContent = `
    .keyboard-nav *:focus {
        outline: 3px solid var(--primary-red) !important;
        outline-offset: 2px !important;
    }
`;
document.head.appendChild(focusStyle);

// ===== PRELOADER (optional - can be enabled) =====
function createPreloader() {
    const preloader = document.createElement('div');
    preloader.id = 'preloader';
    preloader.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: var(--bg-black);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        transition: opacity 0.5s ease, visibility 0.5s ease;
    `;
    
    preloader.innerHTML = `
        <div style="text-align: center;">
            <div style="font-family: 'Bebas Neue', cursive; font-size: 4rem; color: var(--primary-red); margin-bottom: 20px;">
                MMS
            </div>
            <div style="width: 200px; height: 4px; background: #2a2a2a; border-radius: 2px; overflow: hidden;">
                <div style="width: 0%; height: 100%; background: var(--primary-red); animation: loading 2s ease-in-out;"></div>
            </div>
        </div>
    `;
    
    const loadingStyle = document.createElement('style');
    loadingStyle.textContent = `
        @keyframes loading {
            0% { width: 0%; }
            100% { width: 100%; }
        }
    `;
    document.head.appendChild(loadingStyle);
    
    document.body.prepend(preloader);
    
    window.addEventListener('load', function() {
        setTimeout(() => {
            preloader.style.opacity = '0';
            preloader.style.visibility = 'hidden';
            setTimeout(() => {
                preloader.remove();
            }, 500);
        }, 1000);
    });
}

// Uncomment to enable preloader
// createPreloader();

// ===== EXPORT FOR TESTING =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        animateCounter,
        createScrollToTopButton,
        createRacingLines
    };
}

console.log('🏁 Maple Motorsports JavaScript loaded successfully!');